package com.daepamarket.daepa_market_backend.admin.check;

import com.daepamarket.daepa_market_backend.admin.delivery.AdminDeliveryRepository;
import com.daepamarket.daepa_market_backend.domain.check.CheckEntity;
import com.daepamarket.daepa_market_backend.domain.check.CheckRepository;
import com.daepamarket.daepa_market_backend.domain.deal.DealEntity;
import com.daepamarket.daepa_market_backend.domain.delivery.DeliveryEntity;
import com.daepamarket.daepa_market_backend.domain.user.UserEntity;
import com.daepamarket.daepa_market_backend.domain.user.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CheckService {

    private final CheckRepository checkRepository;
    private final AdminDeliveryRepository deliveryRepository;
    private final UserRepository userRepository; // 판매자 조회를 위해 UserRepository 추가

    public List<CheckDTO> getAllChecks() {
        return checkRepository.findAllCheckRows().stream()
                .map(row -> {
                    Long ckIdx = ((Number) row[0]).longValue();
                    Long dIdx = ((Number) row[1]).longValue();
                    String productName = (String) row[2];
                    String sellerName = (String) row[3];
                    String tradeType = (String) row[4];
                    Integer ckStatus = ((Number) row[5]).intValue();
                    Integer ckResult = row[6] != null ? ((Number) row[6]).intValue() : null;
                    
                    // 배송 상태 조회
                    Integer dvStatus = null;
                    DeliveryEntity delivery = deliveryRepository.findByCheckCkIdx(ckIdx).orElse(null);
                    if (delivery != null) {
                        dvStatus = delivery.getDvStatus();
                    }
                    
                    return new CheckDTO(ckIdx, dIdx, productName, sellerName, tradeType, ckStatus, ckResult, dvStatus);
                })
                .collect(Collectors.toList());
    }

    @Transactional
    public void updateCheckResult(Long ckIdx, int result) {
        CheckEntity check = checkRepository.findById(ckIdx)
                .orElseThrow(() -> new RuntimeException("검수 정보를 찾을 수 없습니다."));
        
        // 이미 검수 완료된 경우 예외 처리
        if (check.getCkStatus() == 1 && check.getCkResult() != null) {
            throw new RuntimeException("이미 검수 결과가 등록된 항목입니다.");
        }

        // 검수 상태와 결과 업데이트 (이미 등록된 경우에도 수정 가능)
        // 검수 결과를 설정하면 검수 상태도 완료로 변경
        check.setCkStatus(1);
        check.setCkResult(result);
        checkRepository.save(check);
        
        // 배송 정보가 있는 경우 매너 온도만 업데이트 (배송 상태는 변경하지 않음)
        DeliveryEntity delivery = deliveryRepository.findByCheckCkIdx(ckIdx).orElse(null);
        if (delivery != null) {
            DealEntity deal = delivery.getDeal();
            UserEntity seller = deal.getSeller();
            double currentManner = seller.getUManner();

            // 검수 결과에 따라 매너 온도만 조정 (배송 상태는 배송 관리에서만 변경)
            if (result == 0) { // 합격
                double newManner = Math.min(100, currentManner + 5.0);
                seller.setUManner(newManner);
                userRepository.save(seller);
            } else if (result == 1) { // 불합격
                // 매너 온도가 0 이하로 내려가지 않도록 방어 로직
                double newManner = Math.max(0, currentManner - 5.0);
                seller.setUManner(newManner);
                userRepository.save(seller);
            }
        }
        // 배송 상태(dv_status)는 배송 관리에서만 변경됨
        // 검수 완료(ck_status = 1)된 항목은 배송 관리에서 배송전(0) 상태로 표시됨
    }
}
