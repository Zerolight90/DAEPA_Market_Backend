package com.daepamarket.daepa_market_backend.userpick;

import java.util.List;
import java.util.stream.Collectors;

import com.daepamarket.daepa_market_backend.domain.alarm.AlarmEntity;
import com.daepamarket.daepa_market_backend.domain.alarm.AlarmRepository;
import com.daepamarket.daepa_market_backend.domain.product.ProductEntity;
import com.daepamarket.daepa_market_backend.domain.product.ProductRepository;
import com.daepamarket.daepa_market_backend.domain.userpick.UserPickEntity;
import com.daepamarket.daepa_market_backend.domain.userpick.UserPickRepository;
import com.daepamarket.daepa_market_backend.product.ProductNotificationDTO;
import org.springframework.stereotype.Service;

import com.daepamarket.daepa_market_backend.domain.Category.CtLowEntity;
import com.daepamarket.daepa_market_backend.domain.Category.CtLowRepository;
import com.daepamarket.daepa_market_backend.domain.Category.CtMiddleEntity;
import com.daepamarket.daepa_market_backend.domain.Category.CtMiddleRepository;
import com.daepamarket.daepa_market_backend.domain.Category.CtUpperEntity;
import com.daepamarket.daepa_market_backend.domain.Category.CtUpperRepository;
import com.daepamarket.daepa_market_backend.domain.user.UserEntity;

import lombok.RequiredArgsConstructor;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Transactional
public class UserPickService {

    private final UserPickRepository userPickRepository;
    private final ProductRepository productRepository;
    private final AlarmRepository alarmRepository;

    private final CtUpperRepository ctUpperRepository;
    private final CtMiddleRepository ctMiddleRepository;
    private final CtLowRepository ctLowRepository;

    // 특정 사용자의 모든 관심 상품 목록 조회
    @Transactional(readOnly = true)
    public List<UserPickCreateRequestDto> findPicksByUser(UserEntity user) {
        List<UserPickEntity> entities = userPickRepository.findByUser(user);

        //return userPickRepository.findByUser(user);
        return entities.stream()
                .map(UserPickCreateRequestDto::new)
                .collect(Collectors.toList());
    }

    // 관심 상품 삭제
    public void deletePick(Long upIdx) {
        // 먼저 해당 ID의 데이터가 존재하는지 확인 (선택사항이지만 더 안전)
        if (!userPickRepository.existsById(upIdx)) {
            throw new RuntimeException("해당 관심 상품을 찾을 수 없습니다. ID: " + upIdx);
        }
        userPickRepository.deleteById(upIdx);
    }

    // 관심 상품 생성 및 저장 메소드 추가
    public UserPickCreateRequestDto createPick(UserPickCreateRequestDto requestDto, UserEntity user) {
        // 1. 카테고리 엔티티 조회
        CtUpperEntity ctUpperEntity = ctUpperRepository.findByUpperCt(requestDto.getUpperCategory())
                .orElseThrow(() -> new RuntimeException("상위 카테고리를 찾을 수 없음: " + requestDto.getUpperCategory()));

        CtMiddleEntity ctMiddleEntity = ctMiddleRepository.findByMiddleCt(requestDto.getMiddleCategory())
                .orElseThrow(() -> new RuntimeException("중간 카테고리를 찾을 수 없음: " + requestDto.getMiddleCategory()));

        CtLowEntity ctLowEntity = ctLowRepository.findByLowCt(requestDto.getLowCategory())
                .orElseThrow(() -> new RuntimeException("하위 카테고리를 찾을 수 없음: " + requestDto.getLowCategory()));

        // 2. 엔티티 생성
        UserPickEntity newPick = UserPickEntity.builder()
                .user(user)
                .ctUpper(ctUpperEntity)
                .ctMiddle(ctMiddleEntity)
                .ctLow(ctLowEntity)
                .minPrice(requestDto.getMinPrice())
                .maxPrice(requestDto.getMaxPrice())
                .build();

        // 3. 엔티티 저장 (DB INSERT)
        UserPickEntity savedEntity = userPickRepository.save(newPick);

        // 4. ✅ 저장된 엔티티를 이용해 DTO를 생성하여 반환 (트랜잭션 내에서!)
        return new UserPickCreateRequestDto(savedEntity);
    }

    @Transactional(readOnly = true)
    public List<ProductNotificationDTO> getNotificationsForPick(UserPickDTO pick, Long uIdx) {
        List<AlarmEntity> alarms = alarmRepository.findMatchingAlarmsForUser(
                uIdx,
                pick.getUpperCategory(),
                pick.getMiddleCategory(),
                pick.getLowCategory(),
                pick.getMinPrice(),
                pick.getMaxPrice()
        );

        return alarms.stream()
                .map(alarm -> new ProductNotificationDTO(
                        alarm.getProduct().getPdIdx(),
                        alarm.getProduct().getPdTitle()))
                .collect(Collectors.toList());
    }

}