package com.daepamarket.daepa_market_backend.deal;


import com.daepamarket.daepa_market_backend.domain.deal.DealBuyHistoryDTO;
import com.daepamarket.daepa_market_backend.domain.deal.DealSellHistoryDTO;
import com.daepamarket.daepa_market_backend.domain.user.UserEntity;
import com.daepamarket.daepa_market_backend.domain.user.UserRepository;
import com.daepamarket.daepa_market_backend.jwt.JwtProvider;
import com.daepamarket.daepa_market_backend.pay.PayService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/deal")
public class DealController {

    private final DealService dealService;
    private final PayService payService; // ??PayService 주입
    private final JwtProvider jwtProvider;
    private final UserRepository userRepository;

    /**
     * ??[?�규] 구매 ?�정 API
     * @param dealId ?�정??거래 ID
     * @param request ?�용???�증???�한 HttpServletRequest
     */
    @PostMapping("/{dealId}/confirm")
    public ResponseEntity<?> confirmPurchase(
            @PathVariable Long dealId,
            HttpServletRequest request) {
        try {
            // 1. ?�큰?�서 ?�용??ID 추출 (기존 로직 ?�용)
            String auth = request.getHeader("Authorization");
            if (auth == null || !auth.startsWith("Bearer ")) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "?�증 ?�큰???�습?�다."));
            }
            String token = auth.substring(7);
            if (jwtProvider.isExpired(token)) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "?�큰??만료?�었?�니??"));
            }
            Long userId = Long.valueOf(jwtProvider.getUid(token));

            // 2. ?�비??로직 ?�출
            payService.finalizePurchase(dealId, userId);
            dealService.buyerMannerUp(userId);

            return ResponseEntity.ok(Map.of("message", "구매가 ?�공?�으�??�정?�었?�니?? ?�매?�에�??�산???�료?�니??"));

        } catch (AccessDeniedException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(Map.of("error", e.getMessage()));
        } catch (IllegalStateException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            // ?�버 ?�류 로깅 (?�제 ?�영??중요)
            // log.error("구매 ?�정 처리 �??�류 발생: dealId={}, userId={}", dIdx, userId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("error", "구매 ?�정 처리 �??�버 ?�류가 발생?�습?�다."));
        }
    }

    // ?�전결제 ?�산 ?�역 (?��? ??�?
    @GetMapping("/safe")
    public ResponseEntity<?> getMySettlements(HttpServletRequest request) {
        return dealService.getMySettlements(request);
    }

    @GetMapping("/mySell")
    public ResponseEntity<?> getMySell(HttpServletRequest request) {
        try {
            // 1) Authorization ?�더 꺼내�?
            String auth = request.getHeader("Authorization");
            if (auth == null || !auth.startsWith("Bearer ")) {
                return ResponseEntity.status(401).body("?�큰???�습?�다.");
            }

            // 2) Bearer ?�라?�기
            String token = auth.substring(7);

            // 3) ?�큰 만료 ?�인
            if (jwtProvider.isExpired(token)) {
                return ResponseEntity.status(401).body("?�효?��? ?��? ?�큰?�니??");
            }

            // 4) ?�큰?�서 userId 뽑기
            Long userId = Long.valueOf(jwtProvider.getUid(token));

            // 5) DB??진짜 존재?�는지 체크
            UserEntity user = userRepository.findById(userId).orElse(null);
            if (user == null) {
                return ResponseEntity.status(404).body("?�용?��? 찾을 ???�습?�다.");
            }

            // 6) ?�매??idx = ?�큰 주인??거래�?조회
            List<DealSellHistoryDTO> list = dealService.getMySellHistory(userId);

            return ResponseEntity.ok(list);

        } catch (Exception e) {
            return ResponseEntity.status(500).body("?�버 ?�류가 발생?�습?�다.");
        }
    }

    @GetMapping("/myBuy")
    public ResponseEntity<?> getMyBuys(HttpServletRequest request) {
        try {
            String auth = request.getHeader("Authorization");
            if (auth == null || !auth.startsWith("Bearer ")) {
                return ResponseEntity.status(401).body("?�큰???�습?�다.");
            }

            String token = auth.substring(7);
            if (jwtProvider.isExpired(token)) {
                return ResponseEntity.status(401).body("?�효?��? ?��? ?�큰?�니??");
            }

            Long uIdx = Long.valueOf(jwtProvider.getUid(token));

            List<DealBuyHistoryDTO> list = dealService.getMyBuyHistory(uIdx);

            return ResponseEntity.ok(list);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("?�버 ?�류: " + e.getMessage());
        }
    }


    //구매?�역?�서 구매?�정 버튼
    @PatchMapping("/{dealId}/buy-confirm")
    public ResponseEntity<?> confirmBuy(
            @PathVariable Long dealId,
            HttpServletRequest request
    ) {
        try {
            String auth = request.getHeader("Authorization");
            if (auth == null || !auth.startsWith("Bearer ")) {
                return ResponseEntity.status(401).body("?�큰???�습?�다.");
            }

            String token = auth.substring(7);
            if (jwtProvider.isExpired(token)) {
                return ResponseEntity.status(401).body("?�효?��? ?��? ?�큰?�니??");
            }

            Long uIdx = Long.valueOf(jwtProvider.getUid(token)); // 로그?�한 ?�람(구매??

            // ?�비?�에 ?�임
            dealService.confirmBuy(dealId, uIdx);

            return ResponseEntity.ok("구매?�정 ?�료");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(403).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("?�버 ?�류: " + e.getMessage());
        }
    }

    @GetMapping("/safe/count")
    public ResponseEntity<Map<String, Long>> getSettlementCount(
            @RequestParam(name = "uIdx") Long uIdx
    ) {
        long count = dealService.getSettlementCount(uIdx); // ?�는 getSettlementCountLastYear
        return ResponseEntity.ok(Map.of("count", count));
    }


}

